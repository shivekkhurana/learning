function [ o ] = connectivity( num_e_x, num_e_y )
    for i=1:num_e_x
        for j=1:num_e_y
            
        end
    end
end

